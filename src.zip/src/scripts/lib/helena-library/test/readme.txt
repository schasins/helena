# to test, run the command below from this directory
jasmine
